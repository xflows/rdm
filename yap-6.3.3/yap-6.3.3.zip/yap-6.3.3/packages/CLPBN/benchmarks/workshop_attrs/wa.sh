#!/bin/bash

NETWORK="'../../examples/workshop_attrs.pfl'"
SHORTNAME="wa"
QUERY="series(X)"

N_ATTRS=6


