#!/bin/bash

cd workshop_attrs
source hve_tests.sh
source bp_tests.sh
source lve_tests.sh
source lbp_tests.sh
source cbp_tests.sh
cd ..

cd comp_workshops
source hve_tests.sh
source bp_tests.sh
source lve_tests.sh
source lbp_tests.sh
source cbp_tests.sh
cd ..

cd city
source hve_tests.sh
source bp_tests.sh
source lve_tests.sh
source lbp_tests.sh
source cbp_tests.sh
cd ..

cd social_network2
source hve_tests.sh
source bp_tests.sh
source lve_tests.sh
source lbp_tests.sh
source cbp_tests.sh
cd ..


