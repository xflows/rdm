#!/bin/bash

NETWORK="'../../examples/social_network2.pfl'"
SHORTNAME="sn2ev"
QUERY="query(X)"

POP=500

