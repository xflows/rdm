#!/bin/bash

NETWORK="'../../examples/social_network2.pfl'"
SHORTNAME="sn2"
#QUERY="smokes(p1,t), smokes(p2,t), friends(p1,p2,X)"
QUERY="friends(p1,p2,X)"

