#!/bin/bash

NETWORK="'../../examples/city.pfl'"
SHORTNAME="city"
QUERY="is_joe_guilty(X)"

