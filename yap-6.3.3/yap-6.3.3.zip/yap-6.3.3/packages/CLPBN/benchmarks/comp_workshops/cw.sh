#!/bin/bash

NETWORK="'../../examples/comp_workshops.pfl'"
SHORTNAME="cw"
QUERY="series(X)"

N_WORKSHOPS=10

