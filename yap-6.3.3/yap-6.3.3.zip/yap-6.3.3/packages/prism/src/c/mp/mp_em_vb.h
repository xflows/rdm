/* -*- c-basic-offset: 4 ; tab-width: 4 -*- */

#ifndef MP_EM_VB_H
#define MP_EM_VB_H

/*-------------------------------------------------------------------------*/

void mpm_share_preconds_vbem(void);
void mps_share_preconds_vbem(void);
int mpm_run_vbem(VBEM_ENG_PTR);
int mps_run_vbem(VBEM_ENG_PTR);

/*-------------------------------------------------------------------------*/

#endif /* MP_EM_VB_H */
