/* -*- c-basic-offset: 4 ; tab-width: 4 -*- */

#ifndef MP_EM_ML_H
#define MP_EM_ML_H

/*-------------------------------------------------------------------------*/

void mpm_share_preconds_em(int *);
void mps_share_preconds_em(int *);
int mpm_run_em(EM_ENG_PTR);
int mps_run_em(EM_ENG_PTR);

/*-------------------------------------------------------------------------*/

#endif /* MP_EM_ML_H */
