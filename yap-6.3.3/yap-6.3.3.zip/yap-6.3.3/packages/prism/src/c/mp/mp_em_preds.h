/* -*- c-basic-offset: 4 ; tab-width: 4 -*- */

#ifndef MP_EM_PREDS_H
#define MP_EM_PREDS_H

/*-------------------------------------------------------------------------*/

int pc_mpm_prism_em_6(void);
int pc_mps_prism_em_0(void);
int pc_mpm_prism_vbem_2(void);
int pc_mps_prism_vbem_0(void);
int pc_mpm_prism_both_em_7(void);
int pc_mps_prism_both_em_0(void);
int pc_mpm_import_graph_stats_4(void);
int pc_mps_import_graph_stats_0(void);

/*-------------------------------------------------------------------------*/

#endif /* MP_EM_PREDS_H */
