/* -*- c-basic-offset: 4 ; tab-width: 4 -*- */

#ifndef MP_FLAGS_H
#define MP_FLAGS_H

/*-------------------------------------------------------------------------*/

int pc_mpm_share_prism_flags_0(void);
int pc_mps_share_prism_flags_0(void);

/*-------------------------------------------------------------------------*/

#endif /* MP_FLAGS_H */
