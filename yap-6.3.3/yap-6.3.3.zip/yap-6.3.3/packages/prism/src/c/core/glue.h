#ifndef GLUE_H
#define GLUE_H

void bp4p_init(void);
void bp4p_exit(int);
void bp4p_quit(int);
void bp4p_register_preds(void);

#endif /* GLUE_H */
