#ifndef GAMMA_H
#define GAMMA_H

double lngamma(double);
double digamma(double);

#endif /* GAMMA_H */
