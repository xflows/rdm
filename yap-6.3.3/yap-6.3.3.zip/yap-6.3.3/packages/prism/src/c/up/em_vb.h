#ifndef EM_VB_H
#define EM_VB_H

void config_vbem(VBEM_ENG_PTR);
int  run_vbem(VBEM_ENG_PTR);

#endif /* EM_VB_H */

