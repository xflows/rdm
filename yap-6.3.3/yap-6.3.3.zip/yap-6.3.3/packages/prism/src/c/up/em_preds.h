#ifndef EM_PREDS_H
#define EM_PREDS_H

int pc_prism_prepare_4(void);
int pc_prism_em_6(void);
int pc_prism_vbem_2(void);
int pc_prism_both_em_7(void);
int pc_compute_inside_2(void);
int pc_compute_probf_1(void);

#endif /* EM_PREDS_H */
