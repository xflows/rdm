#ifndef EM_ML_H
#define EM_ML_H

void config_em(EM_ENG_PTR);
int  run_em(EM_ENG_PTR);

#endif /* EM_ML_H */

